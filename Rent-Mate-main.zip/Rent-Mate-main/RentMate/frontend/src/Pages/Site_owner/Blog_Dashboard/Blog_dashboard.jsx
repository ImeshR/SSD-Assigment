import React from 'react'
import Sidebar from '../../../../components/com.mainDashboard/sidebar/Sidebar'

function blog_dashboard() {
  return (
    <div>
      <Sidebar />

    </div>
  )
}

export default blog_dashboard
