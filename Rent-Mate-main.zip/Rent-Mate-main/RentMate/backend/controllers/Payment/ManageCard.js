import ManageCard from '../../models/Payment/P_method';

